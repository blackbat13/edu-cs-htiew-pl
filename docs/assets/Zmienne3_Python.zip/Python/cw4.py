x = 10
y = 15
x = x + y

print("x =", x)
