a = "jabłko"
b = "gruszka"

print("Po inicjalizacji:")
print("a =", a)
print("b =", b)

c = a
a = b
b = c

print()
print("Po zamianie:")
print("a =", a)
print("b =", b)