suma = 0
for i in range(1, 11):
    suma += i

print("suma =", suma)
