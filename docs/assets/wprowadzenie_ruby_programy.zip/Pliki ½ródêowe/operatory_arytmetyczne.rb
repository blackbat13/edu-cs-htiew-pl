a = 10
b = 3

suma = a + b          # 13
roznica = a - b       # 7
iloczyn = a * b       # 30
iloraz = a / b        # 3
iloraz2 = a.to_f / b  # 3.3333...
modulo = a % b        # 1
potega = a ** b       # 1000

