
student = {imie: "Jan", nazwisko: "Kowalski", wiek: 22}

puts student  # {:imie=>"Jan", :nazwisko=>"Kowalski", :wiek=>22}

puts student[:imie]  # Jan