
def suma(a, b)
  a + b
end

puts suma(2, 5)   # 7



def punkt(a)
  x = a
  y = a * 2
  return x, y
end

puts punkt(5)        # 5 10