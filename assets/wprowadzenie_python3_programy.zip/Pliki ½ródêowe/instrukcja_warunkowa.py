temperatura = 25

if temperatura < 10:
    print("Zimno!")
elif temperatura < 20:
    print("Cieplo!")
else:
    print("Goraco!")