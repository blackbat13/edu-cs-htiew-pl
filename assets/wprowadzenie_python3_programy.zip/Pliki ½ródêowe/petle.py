
print("Petla warunkowa while")

x = 0
while x < 10:
    print(f"x = {x}")
    x += 1


print("Petla liczaca for")

for i in range(0, 10):
    print(f"i = {i}")


print("Petla liczaca for z ujemnym krokiem")

for i in range(10, 0, -1):
    print(f"i = {i}")
