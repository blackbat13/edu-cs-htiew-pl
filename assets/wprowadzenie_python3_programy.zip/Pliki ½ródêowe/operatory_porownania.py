a = 10
b = 5

a == b   # False
a != b   # True
a < b    # False
a <= b   # False
a > b    # True
a >= b   # True

