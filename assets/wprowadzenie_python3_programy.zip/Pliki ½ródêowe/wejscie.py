tekst = input("Podaj tekst")

liczba = int(input("Podaj liczbe"))