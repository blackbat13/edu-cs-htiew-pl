print("Hello World!")

a = 10
print("a = " + str(a))
print(f"a = {a}")