def kwadrat_liczby(liczba):
    return liczba * liczba


liczba = int(input("Podaj liczbę "))
wynik = kwadrat_liczby(liczba)
print(f'Kwadrat podanej liczby: {wynik}')